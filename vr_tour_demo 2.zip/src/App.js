import React from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Sphere, MeshBasicMaterial } from '@react-three/drei';
import * as THREE from 'three';

function VRTour() {
  const texture = new THREE.TextureLoader().load(process.env.PUBLIC_URL + '/sample-360.jpg');

  return (
    <Canvas>
      <OrbitControls enableZoom={true} enablePan={true} enableRotate={true} />
      <Sphere args={[500, 60, 40]} scale={[-1, 1, 1]}>
        <meshBasicMaterial map={texture} side={THREE.BackSide} />
      </Sphere>
    </Canvas>
  );
}

function App() {
  return (
    <div style={{ height: '100vh', width: '100vw' }}>
      <VRTour />
    </div>
  );
}

export default App;
